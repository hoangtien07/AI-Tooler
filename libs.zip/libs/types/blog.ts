// libs/types/blog.ts
export type Locale = "vi" | "en";

export interface LocalizedString {
  vi: string;
  en: string;
}

export interface PackedContent {
  raw?: unknown;
  html?: string;
  text?: string;
}

export interface LocalizedRich {
  vi: PackedContent;
  en: PackedContent;
}

export type BlogStatus = "draft" | "active" | "archived";
export type BlogSource = "notion" | "manual";

export interface Blog {
  _id: string;
  slug: string;
  title: LocalizedString;
  excerpt: LocalizedString;
  content: LocalizedRich;
  tags: string[];
  image?: string;
  status: BlogStatus;
  publishedAt?: string;
  source?: BlogSource;
  sourceUrl?: string;
  createdAt?: string;
  updatedAt?: string;
  __v?: number;
}

export interface Paged<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
}


export type BlogListQuery = {
  q?: string;
  tag?: string; // ✅ thêm tag
  status?: string;
  skip?: number;
  limit?: number;
  sort?: string;
  lang?: Locale; // dùng cho BE (optional)
};