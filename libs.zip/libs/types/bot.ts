export type Bot = {
  _id: string;
  name: string;
  slug: string;
  image?: string;
  summary?: string;
  description?: string;
  category?: string;
  tags?: string[];
  features?: string[];
  views?: number;
  clicks?: number;
  seo?: {
    title?: string;
    description?: string;
    ogImage?: string;
    canonical?: string;
  };
  createdAt?: string;
};
