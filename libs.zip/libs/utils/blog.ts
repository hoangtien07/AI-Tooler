// libs/utils/blog.ts
import type { Blog, Locale } from "../types/blog";

export const pickTitle = (b: Blog, lang: Locale): string =>
  b.title[lang] ?? b.title.en;

export const pickExcerpt = (b: Blog, lang: Locale): string =>
  b.excerpt[lang] ?? b.excerpt.en;

export const pickHtml = (b: Blog, lang: Locale): string =>
  b.content[lang]?.html ?? b.content.en?.html ?? "";

export const toPlain = (html: string): string =>
  html
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();

export const short = (s: string, max = 160): string =>
  s.length > max ? s.slice(0, max) : s;

export const formatDate = (iso?: string): string =>
  iso
    ? new Date(iso).toLocaleDateString("vi-VN", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : "";

export const estimateReadingMin = (html: string): number => {
  const words = toPlain(html).split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 200));
};

export type TocLevel = 1 | 2 | 3 | 4 | 5 | 6;

export interface TocItem {
  id: string;
  text: string;
  level: TocLevel;
}

export const slugifyId = (s: string): string =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");
