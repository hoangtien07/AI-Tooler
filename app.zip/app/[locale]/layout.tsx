
import { Geist, Geist_Mono } from "next/font/google";
import type { Metadata } from "next";
import { ThemeProvider } from "@/components/Layout/Themes/theme-provider";
import NavBar from "@/components/Layout/Navbar/Navbar";
import { I18nProvider } from "@/libs/I18nProvider";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "AI-Tooler"
};

export default async function RootLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ locale: "vi" | "en" }>;
}) {
  const { locale } = await params;
  return (
    <html lang={locale} suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased relative overflow-x-hidden`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <I18nProvider initialLocale={locale}>
            <NavBar initialLocale={locale} />
            <main className="main-content">
              <div>{children}</div>
            </main>
            <footer className="footer  text-neutral-600 dark:text-white/60 text-xs sm:text-sm">
              <div className="container flex flex-col sm:flex-row justify-between items-center gap-2 p-4 text-center">
                <p>Email contact: support@aitooler.io</p>
                <p>© 2025 AI Tooler. All rights reserved.</p>
              </div>
            </footer>
          </I18nProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
